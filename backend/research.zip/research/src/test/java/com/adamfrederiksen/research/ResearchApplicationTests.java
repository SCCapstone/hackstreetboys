package com.adamfrederiksen.research;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
